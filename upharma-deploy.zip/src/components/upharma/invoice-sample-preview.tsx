'use client';

import React, { useState, useEffect } from 'react';

// ==================== SAMPLE INVOICE PREVIEW (for Settings page) ====================
// Renders a scaled-down preview of the invoice using live store settings

interface StoreInfo {
  storeName: string;
  phone: string;
  address: string;
  gstNumber: string;
  drugLicense: string;
  fssaiNo: string;
  upiId: string;
}

function formatINR(amount: number): string {
  return `Rs. ${amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

// Sample data for preview
const SAMPLE_ITEMS = [
  { name: 'Dolo 650 Tab', qty: 10, batch: 'D650A', exp: 'MAR-27', amount: 28.50 },
  { name: 'Pan D Caps', qty: 5, batch: 'PD2024', exp: 'JUN-27', amount: 95.00 },
  { name: 'Azithromycin 500mg', qty: 3, batch: 'AZT015', exp: 'DEC-26', amount: 147.00 },
];

const SAMPLE_DOCTOR = 'Dr. Sample Doctor';
const SAMPLE_PATIENT = 'Sample Patient';

// Reusable sample invoice body (renders one copy)
function SampleInvoiceBody({ s, invoicePrefix, terms, today, sampleInvNo }: {
  s: StoreInfo;
  invoicePrefix: string;
  terms: string;
  today: string;
  sampleInvNo: string;
}) {
  const subtotal = SAMPLE_ITEMS.reduce((sum, i) => sum + i.amount, 0);
  const grandTotal = subtotal;

  const regLine = [s.drugLicense ? `DL No: ${s.drugLicense}` : '', s.fssaiNo ? `FSSAI: ${s.fssaiNo}` : ''].filter(Boolean).join(' | ');

  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);

  useEffect(() => {
    if (s.upiId) {
      const upiString = `upi://pay?pa=${encodeURIComponent(s.upiId)}&pn=${encodeURIComponent(s.storeName || 'Store')}&am=${grandTotal.toFixed(2)}&cu=INR&tn=${encodeURIComponent(sampleInvNo)}`;
      import('qrcode').then((QRCode) => {
        QRCode.toDataURL(upiString, { width: 150, margin: 1 }).then((url: string) => {
          setQrDataUrl(url);
        }).catch(() => {
          setQrDataUrl(null);
        });
      }).catch(() => {
        setQrDataUrl(null);
      });
    } else {
      setQrDataUrl(null);
    }
  }, [s.upiId, s.storeName, grandTotal, sampleInvNo]);

  return (
    <>
      {/* Store Header */}
      <div style={{ textAlign: 'center', marginBottom: '4px' }}>
        <h2 style={{ fontSize: '15px', fontWeight: 800, fontFamily: 'serif', margin: '0', lineHeight: '1.2', color: '#1a1a1a' }}>
          {s.storeName || 'Your Store Name'}
        </h2>
        <p style={{ fontSize: '9px', color: '#555', margin: '1px 0 0 0' }}>
          {s.address || 'Your Address'}
          {s.phone ? ` | Ph: ${s.phone}` : ''}
        </p>
        <p style={{ fontSize: '8px', color: '#777', margin: '1px 0 0 0' }}>
          {s.drugLicense ? `DL No: ${s.drugLicense}` : ''}
          {s.drugLicense && s.fssaiNo ? ' | ' : ''}
          {s.fssaiNo ? `FSSAI: ${s.fssaiNo}` : ''}
        </p>
      </div>

      {/* CASH MEMO Badge */}
      <div style={{ textAlign: 'center', marginBottom: '6px' }}>
        <span style={{
          display: 'inline-block',
          backgroundColor: '#8B0000',
          color: '#fff',
          padding: '2px 24px',
          fontSize: '11px',
          fontWeight: 800,
          fontFamily: 'sans-serif',
          letterSpacing: '3px',
          borderRadius: '2px',
        }}>
          CASH MEMO
        </span>
      </div>

      {/* Bill No & Date */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        borderTop: '1px solid #CC0000',
        borderBottom: '1px solid #CC0000',
        padding: '3px 6px',
        marginBottom: '4px',
      }}>
        <span style={{ fontSize: '12px', fontWeight: 700, color: '#1a1a1a' }}>{sampleInvNo}</span>
        <span style={{ fontSize: '10px', color: '#333', fontWeight: 500 }}>Date: {today}</span>
      </div>

      {/* Doctor & Customer */}
      <div style={{ marginBottom: '4px', padding: '0 4px' }}>
        <div style={{ fontSize: '10px', color: '#333', marginBottom: '1px', borderBottom: '1px dotted #999', paddingBottom: '1px' }}>
          <span style={{ fontWeight: 600 }}>Dr.: </span>
          <span>{SAMPLE_DOCTOR}</span>
        </div>
        <div style={{ fontSize: '10px', color: '#333', borderBottom: '1px dotted #999', paddingBottom: '1px' }}>
          <span style={{ fontWeight: 600 }}>Customer: </span>
          <span>{SAMPLE_PATIENT}</span>
        </div>
      </div>

      {/* Items Table */}
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '9px', marginBottom: '4px' }}>
        <thead>
          <tr style={{ backgroundColor: '#f5f0f0' }}>
            {[
              { label: '#', w: '6%', a: 'center' },
              { label: 'Particulars', w: '32%', a: 'left' },
              { label: 'Qty', w: '7%', a: 'center' },
              { label: 'Comp.', w: '20%', a: 'left' },
              { label: 'Batch', w: '13%', a: 'center' },
              { label: 'Exp.', w: '10%', a: 'center' },
              { label: 'Amount Rs.', w: '12%', a: 'right' },
            ].map(col => (
              <th key={col.label} style={{
                border: '1px solid #CC0000',
                padding: '2px 3px',
                textAlign: col.a,
                fontWeight: 700,
                fontSize: '8px',
                color: '#1a1a1a',
                width: col.w,
                backgroundColor: '#f5f0f0',
              }}>
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {SAMPLE_ITEMS.map((item, idx) => (
            <tr key={idx}>
              <td style={{ border: '1px solid #CC0000', padding: '2px 3px', textAlign: 'center', color: '#444' }}>{idx + 1}</td>
              <td style={{ border: '1px solid #CC0000', padding: '2px 3px', textAlign: 'left', fontWeight: 600, color: '#1a1a1a', fontSize: '8.5px' }}>{item.name}</td>
              <td style={{ border: '1px solid #CC0000', padding: '2px 3px', textAlign: 'center', color: '#333' }}>{item.qty}</td>
              <td style={{ border: '1px solid #CC0000', padding: '2px 3px', textAlign: 'left', color: '#555', fontSize: '8px' }}></td>
              <td style={{ border: '1px solid #CC0000', padding: '2px 3px', textAlign: 'center', color: '#444', fontSize: '8px' }}>{item.batch}</td>
              <td style={{ border: '1px solid #CC0000', padding: '2px 3px', textAlign: 'center', color: '#444', fontSize: '8px' }}>{item.exp}</td>
              <td style={{ border: '1px solid #CC0000', padding: '2px 3px', textAlign: 'right', fontWeight: 600, color: '#1a1a1a' }}>{formatINR(item.amount)}</td>
            </tr>
          ))}
          {/* Fill rows */}
          {Array.from({ length: 4 }).map((_, idx) => (
            <tr key={`e-${idx}`}>
              {Array.from({ length: 7 }).map((_, ci) => (
                <td key={ci} style={{ border: '1px solid #CC0000', padding: '2px 3px', height: '14px' }}>&nbsp;</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      {/* Totals */}
      <div style={{ borderTop: '1px solid #CC0000', paddingTop: '3px', marginBottom: '3px' }}>
        <table style={{ width: '100%', fontSize: '9px' }}>
          <tbody>
            <tr>
              <td colSpan={2} style={{ borderTop: '1px solid #CC0000', padding: '0' }} />
            </tr>
            <tr>
              <td style={{ textAlign: 'left', padding: '3px 4px', fontSize: '11px', fontWeight: 800, color: '#1a1a1a' }}>GRAND TOTAL</td>
              <td style={{ textAlign: 'right', padding: '3px 4px', fontSize: '11px', fontWeight: 800, color: '#8B0000' }}>{formatINR(grandTotal)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Payment */}
      <div style={{ fontSize: '9px', color: '#555', marginBottom: '4px', padding: '0 4px' }}>
        <span style={{ fontWeight: 600 }}>Payment: </span><span>Cash</span>
      </div>

      {/* Footer with QR Code */}
      <div style={{ borderTop: '1px solid #CC0000', paddingTop: '3px', padding: '3px 4px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div style={{ flex: 1 }}>
          <p style={{ textAlign: 'center', fontSize: '8px', color: '#555', margin: '0 0 2px 0', fontStyle: 'italic' }}>
            Thank you for your purchase! Visit again.
          </p>
          {terms && (
            <p style={{ textAlign: 'center', fontSize: '7px', color: '#888', margin: '0 0 1px 0', whiteSpace: 'pre-line', lineHeight: '1.4' }}>
              {terms.split('\n').slice(0, 2).join(' | ')}
            </p>
          )}
          {regLine && (
            <p style={{ textAlign: 'center', fontSize: '7px', color: '#999', margin: '0' }}>{regLine}</p>
          )}
        </div>
        {qrDataUrl && (
          <div style={{ marginLeft: '8px', textAlign: 'center', flexShrink: 0 }}>
            <img
              src={qrDataUrl}
              alt="UPI QR Code"
              style={{ width: '80px', height: '80px', border: '1px solid #ddd', borderRadius: '4px' }}
            />
            <p style={{ fontSize: '6px', color: '#888', margin: '1px 0 0 0' }}>Scan to Pay via UPI</p>
          </div>
        )}
      </div>
    </>
  );
}

export function InvoiceSamplePreview({ storeInfo, invoicePrefix, terms }: {
  storeInfo: StoreInfo;
  invoicePrefix: string;
  terms: string;
}) {
  const s = storeInfo;
  const today = new Date().toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const sampleInvNo = `${invoicePrefix || 'INV-'}01042`;

  return (
    <div style={{
      width: '210mm',
      backgroundColor: '#fff',
      padding: '4mm 6mm',
      fontFamily: 'Arial, Helvetica, sans-serif',
      fontSize: '9px',
      color: '#1a1a1a',
      lineHeight: 1.3,
      border: '1px solid #ddd',
      margin: '0 auto',
    }}>
      {/* ========== CUSTOMER COPY ========== */}
      <div style={{ textAlign: 'center', fontSize: '8px', fontWeight: 700, letterSpacing: '2px', textTransform: 'uppercase', color: '#999', marginBottom: '2px' }}>
        Customer Copy
      </div>

      <SampleInvoiceBody s={s} invoicePrefix={invoicePrefix} terms={terms} today={today} sampleInvNo={sampleInvNo} />

      {/* ========== CUT LINE ========== */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: '8px',
        margin: '10px 0', padding: '0 10mm',
      }}>
        <div style={{ flex: 1, borderTop: '1px dashed #aaa' }} />
        <span style={{ fontSize: '8px', color: '#aaa', fontWeight: 600, letterSpacing: '1px' }}>
          ✂ Cut Here ✂
        </span>
        <div style={{ flex: 1, borderTop: '1px dashed #aaa' }} />
      </div>

      {/* ========== STORE COPY (abbreviated) ========== */}
      <div style={{ textAlign: 'center', fontSize: '8px', fontWeight: 700, letterSpacing: '2px', textTransform: 'uppercase', color: '#999', marginBottom: '2px' }}>
        Store Copy
      </div>

      <SampleInvoiceBody s={s} invoicePrefix={invoicePrefix} terms={terms} today={today} sampleInvNo={sampleInvNo} />
    </div>
  );
}
